def cents(text):
    return int(float(text) * 100)
