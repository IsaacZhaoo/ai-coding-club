import unittest
from amount import cents

class RoundingTests(unittest.TestCase):
    def test_positive(self):
        self.assertEqual(cents('1.005'), 101)

    def test_negative(self):
        self.assertEqual(cents('-1.005'), -101)
