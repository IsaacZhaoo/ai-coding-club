"""Read only test markers and contact only the loopback fixture."""
import json
from pathlib import Path
from urllib.error import URLError
from urllib.request import ProxyHandler, build_opener

result = {"workspace_read": Path("hello.txt").read_text().strip()}
try:
    result["outside_read"] = Path("../outside/sentinel.txt").read_text().strip()
except OSError as error:
    result["outside_read"] = type(error).__name__
try:
    with build_opener(ProxyHandler({})).open("http://127.0.0.1:18761/ping", timeout=2) as response:
        result["tool_network"] = response.read().decode().strip()
except (OSError, URLError) as error:
    result["tool_network"] = type(error).__name__
print(json.dumps(result, sort_keys=True))
