"""Exercise Copilot CLI against a local fixture in a new, disposable directory."""
import argparse
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--copilot", default="copilot")
    parser.add_argument("--output", default="lab-output")
    args = parser.parse_args()
    executable = shutil.which(args.copilot)
    if not executable:
        parser.error("Copilot CLI is required; pass --copilot with its executable path")
    executable = str(Path(executable).resolve())
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    work, outside, config = (output / name for name in ("work", "outside", "config"))
    for directory in (work, outside, config):
        directory.mkdir()
    source = Path(__file__).resolve().parent
    shutil.copyfile(source / "probe.py", work / "probe.py")
    (work / "hello.txt").write_text("LOCAL_BOUNDARY_OK\n")
    (outside / "sentinel.txt").write_text("OUTSIDE_SENTINEL_NOT_SECRET\n")
    settings = {"sandbox": {
        "enabled": True, "allowBypass": False, "allowDevToolAccess": False,
        "auth": {"git": False, "gh": False},
        "userPolicy": {"filesystem": {"deniedPaths": [str(outside)]},
                       "network": {"allowOutbound": False, "allowLocalNetwork": False}}
    }}
    (config / "settings.json").write_text(json.dumps(settings, indent=2) + "\n")
    # Preserve the real home location; do not inherit tokens or provider settings.
    environment = {key: os.environ[key] for key in ("PATH", "HOME", "USER", "LANG", "TMPDIR") if key in os.environ}
    environment.update({"COPILOT_HOME": str(config), "COPILOT_OFFLINE": "true",
                        "COPILOT_PROVIDER_BASE_URL": "http://127.0.0.1:18761/v1",
                        "COPILOT_MODEL": "boundary-fixture", "COPILOT_AUTO_UPDATE": "false"})
    result = {"version": subprocess.check_output([executable, "--version"], env=environment, text=True).splitlines()[0]}
    with (output / "provider.stderr").open("w") as error_log:
        provider = subprocess.Popen([sys.executable, str(source / "provider.py")], cwd=output,
                                    env=environment, stdout=subprocess.DEVNULL, stderr=error_log)
        try:
            for _ in range(100):
                if provider.poll() is not None:
                    raise RuntimeError("Fixture provider failed to start; see provider.stderr")
                try:
                    with socket.create_connection(("127.0.0.1", 18761), timeout=0.1):
                        break
                except OSError:
                    time.sleep(0.05)
            else:
                raise RuntimeError("Fixture provider did not become ready")
            # Give a port-collision failure time to surface before sending data.
            time.sleep(0.1)
            if provider.poll() is not None:
                raise RuntimeError("Fixture provider exited; is port 18761 occupied?")
            for name, flag in (("baseline", "--no-sandbox"), ("sandbox", "--sandbox")):
                command = [executable, flag, "--disable-builtin-mcps", "--available-tools", "bash",
                           "--allow-tool", "shell(python3)", "--no-ask-user", "--output-format", "json",
                           "-p", "Run the local boundary probe."]
                completed = subprocess.run(command, cwd=work, env=environment, text=True,
                                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
                (output / f"{name}.jsonl").write_text(completed.stdout)
                (output / f"{name}.stderr").write_text(completed.stderr)
                completed.check_returncode()
                events = [json.loads(line) for line in completed.stdout.splitlines() if line.startswith("{")]
                calls = [event["data"] for event in events if event.get("type") == "tool.execution_complete"]
                if len(calls) != 1 or not calls[0].get("success"):
                    raise RuntimeError(f"{name}: expected one successful probe call")
                call = calls[0]
                probe = json.loads(call["result"]["content"].splitlines()[0])
                result[name] = {"sandboxed": call.get("sandboxed", False), **probe}
            receipts = [json.loads(line) for line in (output / "provider-receipts.jsonl").read_text().splitlines()]
            result["provider_requests"] = len(receipts)
            expected = {
                "baseline": {"sandboxed": False, "outside_read": "OUTSIDE_SENTINEL_NOT_SECRET",
                             "tool_network": "LOCAL_PROVIDER_REACHED", "workspace_read": "LOCAL_BOUNDARY_OK"},
                "sandbox": {"sandboxed": True, "outside_read": "FileNotFoundError",
                            "tool_network": "URLError", "workspace_read": "LOCAL_BOUNDARY_OK"}
            }
            result["passed"] = all(result[key] == value for key, value in expected.items()) and len(receipts) >= 4
            (output / "results.json").write_text(json.dumps(result, indent=2) + "\n")
            print(json.dumps(result, indent=2))
            return 0 if result["passed"] else 1
        finally:
            provider.terminate()
            try:
                provider.wait(timeout=5)
            except subprocess.TimeoutExpired:
                provider.kill()
                provider.wait()


if __name__ == "__main__":
    raise SystemExit(main())
