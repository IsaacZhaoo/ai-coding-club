"""Deterministic local protocol fixture; no LLM and no outbound requests."""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        body = b"LOCAL_PROVIDER_REACHED\n"
        self.send_response(200)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        request = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        if self.path != "/v1/chat/completions":
            self.send_error(404)
            return
        messages = request.get("messages", [])
        receipt = {"path": self.path, "model": request.get("model"),
                   "stream": request.get("stream"), "messages": len(messages)}
        with Path("provider-receipts.jsonl").open("a") as file:
            file.write(json.dumps(receipt) + "\n")
        has_result = any(message.get("role") == "tool" for message in messages)
        if has_result:
            delta = {"role": "assistant", "content": "Probe finished. Inspect the tool output for the result."}
            finish = "stop"
        else:
            delta = {"role": "assistant", "tool_calls": [{"index": 0, "id": "boundary_probe", "type": "function",
                     "function": {"name": "bash", "arguments": json.dumps({"command": "python3 probe.py", "description": "Run the local boundary probe"})}}]}
            finish = "tool_calls"
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Connection", "close")
        self.end_headers()
        for content, reason in [(delta, None), ({}, finish)]:
            chunk = {"id": "boundary-fixture", "object": "chat.completion.chunk", "created": 0,
                     "model": "boundary-fixture", "choices": [{"index": 0, "delta": content, "finish_reason": reason}]}
            self.wfile.write(("data: " + json.dumps(chunk) + "\n\n").encode())
        self.wfile.write(b"data: [DONE]\n\n")
        self.wfile.flush()
        self.close_connection = True

if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", 18761), Handler).serve_forever()
