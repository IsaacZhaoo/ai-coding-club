def select_tasks(tasks, status):
    matching = [task for task in tasks if task["status"] == status]
    return sorted(matching, key=lambda task: task["id"])
