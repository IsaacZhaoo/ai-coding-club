import json


def load_tasks(path):
    with path.open(encoding="utf-8") as source:
        return json.load(source)
