# Codebase reading lab / 代码理解练习

A small Python 3 exercise for tracing one command through several files. It uses only the standard library and the bundled JSON input. Python 3 must already be available; no third-party packages or account are required.

这是一个沿命令查找入口和调用关系的 Python 3 小练习，只使用标准库和附带的 JSON 数据。无需安装依赖或注册账号。

## Run / 运行

Open a terminal inside this folder. On Windows, use `python` instead if that is the name of your Python 3 command.

在此目录打开终端。如果 Windows 的 Python 3 命令名是 `python`，替换下面的 `python3`。

```sh
python3 main.py
python3 main.py --status done
```

The first command prints the full records for T1 then T3. The second prints only T2. Each command writes one JSON array to standard output and leaves `tasks.json` unchanged.

第一条命令依次输出 T1、T3 的完整记录；第二条只输出 T2。输出都是标准输出中的一行 JSON 数组，`tasks.json` 保持不变。

## Read / 阅读

Start at `main.py`. Find where arguments become values, follow its two calls into `repository.py` and `query.py`, then identify the JSON output statement. For each claim, cite the actual file and line you inspected.

从 `main.py` 开始，找到参数如何变成值，跟进它对 `repository.py` 和 `query.py` 的两次调用，再找到 JSON 输出语句。每个结论都标明你实际阅读的文件和行号。

Before running, explain why T2 is excluded by default and why T1 appears before T3 although the input puts T3 first. Then predict `--status done` and compare with execution.

运行前解释：默认为什么没有 T2，输入中排在后面的 T1 为什么先输出。再预测 `--status done` 的结果，用实际运行核对。

This fixture assumes well-formed task objects with `id`, `title`, and `status`. It is a reading exercise, not a production task manager. It does not implement schema validation or persistence. If you provide `--data`, a relative path is resolved from your terminal's working directory; the bundled default is next to `main.py`.

示例假设输入记录包含 `id`、`title`、`status`。它用于练习读代码，没有实现完整数据校验或持久化。传入 `--data` 时，相对路径以终端当前目录为起点；默认数据则位于 `main.py` 旁边。

## Use with a chat assistant / 在普通聊天中使用

Manually provide all four files: `main.py`, `repository.py`, `query.py`, and `tasks.json`. Paste complete content with filenames, or attach the files if your chat can read them. Ask it to list what it can read, trace `python3 main.py` with file:line evidence, and predict the output without claiming execution. If sending multiple messages, ask it to wait until all files have arrived.

手动提供 `main.py`、`repository.py`、`query.py`、`tasks.json` 四个文件，粘贴带文件名的完整内容，或在支持读取附件的聊天窗口附上文件。让 AI 先列出实际能读到的材料，再用文件与行号追踪 `python3 main.py`，给出预测并注明没有运行。分多条发送时，先说明等材料齐全再分析。

With only `main.py`, imported implementations and the complete output remain unknown. Ask for the other three files. Do not accept claims about filtering from a function name, or a missing-module error inferred merely because a file was not shared. Check claims against source yourself; prompting cannot guarantee correctness.

只有 `main.py` 时，导入函数的实现和完整输出仍未知，需要另外三个文件。不要仅凭函数名接受筛选规则，也不要把未提供文件当成运行环境缺模块。自己对照源码检查，提示词不能保证回答正确。

## Expected output / 预期输出

`python3 main.py`:

```json
[{"id": "T1", "title": "Find the entry point", "status": "open"}, {"id": "T3", "title": "Write a usage note", "status": "open"}]
```

`python3 main.py --status done`:

```json
[{"id": "T2", "title": "Run the example", "status": "done"}]
```

Check the default status, both call sites, and the sorting code before comparing actual output. If you only read the source, record the result as a prediction; execution verification is still pending.

先检查默认状态、两次调用和排序代码，再比较实际输出。只读源码时，把结果记为预测，运行核验仍待完成。
