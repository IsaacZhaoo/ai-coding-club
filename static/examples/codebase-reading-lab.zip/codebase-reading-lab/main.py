import argparse
import json
from pathlib import Path

from repository import load_tasks
from query import select_tasks


def main():
    parser = argparse.ArgumentParser(description="List tasks by status.")
    parser.add_argument("--status", choices=("open", "done"), default="open")
    parser.add_argument("--data", type=Path, default=Path(__file__).with_name("tasks.json"))
    args = parser.parse_args()
    tasks = load_tasks(args.data)
    result = select_tasks(tasks, args.status)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
